﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// My20200203LJYImgProcess.rc에서 사용되고 있습니다.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_My20200203LJYImgProcessTYPE 130
#define ID_WINDOW_MANAGER               131
#define IDD_DIALOG1                     310
#define IDD_DIALOG2                     311
#define IDD_DIALOG3                     312
#define IDD_DIALOG4                     313
#define IDC_EDIT1                       1000
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_DOWN_SAMPLEING               32773
#define ID_UPSAMPLING                   32774
#define ID_UP_SAMPLING                  32775
#define ID_32776                        32776
#define ID_QUANTIZATION                 32777
#define ID_32778                        32778
#define ID_SUM_CONSTANT                 32779
#define ID_32780                        32780
#define ID_SUB_CONSTANT                 32781
#define ID_32782                        32782
#define ID_MUL_CONSTANT                 32783
#define ID_32784                        32784
#define ID_DIV_CONSTANT                 32785
#define ID_32786                        32786
#define ID_AND_OPERATE                  32787
#define ID_32788                        32788
#define ID_OR_OPERATE                   32789
#define ID_32790                        32790
#define ID_XOR_OPERATE                  32791

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        312
#define _APS_NEXT_COMMAND_VALUE         32792
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
